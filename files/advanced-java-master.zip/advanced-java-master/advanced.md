<p align="center"><iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=1334849028&auto=1&height=66"></iframe></p>
<p align="center">本单曲受版权保护，可<a href="https://music.163.com/#/mv?id=10859500">点击观看 MV</a>。</p>


> 受伤的得到疗愈，挣扎的得到出口<br>
*Let those who hurt heal, let those who struggle find hope*.

```
告别的时刻已到了
随身的行囊 装些快乐

前方被乌云笼罩了
心中的拉扯 困兽在低吼

隐隐约约的沉默
透露一丝丝苦涩
愿你不再被伤透
别再带着泪入睡

曲曲折折的世界
答案不一定绝对
伤口因为爱壮烈
让我们同步进阶

重生的力量来自真我
战胜可敬的对手 yeah~

坚持信念是我的所有
抵达心中的辽阔 yeah~

有失去的 该进阶的
有遗憾的 该进阶的
放不下的 该进阶的 yeah~

圣所的光芒
指引方向 oh~

跨越了浩劫
曙光渐亮 oh~

希望因挣扎破灭了
再别无所求 于是自由

逆着风孤独的英雄
也渴望停泊 可说不出口

隐隐约约的沉默
透露一丝丝苦涩
愿你不再被伤透
别再带着泪入睡

曲曲折折的世界
答案不一定绝对
伤口因为爱壮烈
让我们同步进阶

重生的力量来自真我
战胜可敬的对手 yeah~

坚持信念是我的所有
抵达心中的辽阔 yeah~

有失去的 该进阶的
有遗憾的 该进阶的
放不下的 该进阶的 yeah~

圣所的光芒
指引方向 oh~

跨越了浩劫
曙光渐亮 oh~
```